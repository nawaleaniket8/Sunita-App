insert into alarm (id, name, start, end, priority) values
  (0, 'Wake Up', '06:00:00', '06:05:00', 0),
  (1, 'Sugar Tablet', '10:30:00', '10:45:00', 0),
  (2, 'Nashta', '11:45:00', '12:45:00', 0),
  (3, 'lunch', '14:00:00', '15:00:00', 2),
  (4, 'Rest', '14:30:00', '14:45:00', 0),
  (5, 'BP Tablet', '18:30:00', '21:30:00', 5);